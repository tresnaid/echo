# @atlas/ds

> Layered, accessible, framework-independent UI foundation with production-grade React component primitives.

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![WCAG 2.2 AA](https://img.shields.io/badge/accessibility-WCAG%202.2%20AA-success.svg)](https://www.w3.org/WAI/WCAG22/quickref/)

---

## Features

- 🎯 **52 Stable UI Primitives**: Forms, overlays, navigation, feedback, layout, and data display.
- ♿ **Accessible by Default**: WCAG 2.2 AA compliant, robust ARIA semantics, keyboard interactions, focus trap, and live announcements.
- 🎨 **Multi-Theme & Light/Dark Modes**: Token-driven styling with zero runtime CSS-in-JS overhead. Includes official `atlas` and `editorial` themes.
- ⚡ **Framework-Neutral Architecture**: Clean separation between core token/behavioral foundations and React implementations.
- 📦 **Modern Exports**: Dual ESM/CJS builds with full TypeScript declarations and granular subpath exports.

---

## Installation

```bash
# Using pnpm
pnpm add @atlas/ds react react-dom

# Using npm
npm install @atlas/ds react react-dom

# Using yarn
yarn add @atlas/ds react react-dom
```

---

## Quickstart

### 1. Import Stylesheet

Import the complete unified stylesheet in your application's entrypoint:

```typescript
import '@atlas/ds/styles.css';
```

### 2. Wrap with Providers

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ThemeProvider, AnnouncementProvider, Button, Card, Field, Input } from '@atlas/ds';
import '@atlas/ds/styles.css';

function App() {
  return (
    <ThemeProvider defaultTheme="atlas" defaultMode="system">
      <AnnouncementProvider>
        <main style={{ padding: '2rem' }}>
          <Card>
            <h2>Atlas Design System</h2>
            <Field label="Username">
              <Input placeholder="Enter username..." />
            </Field>
            <Button variant="primary" onClick={() => alert('Hello Atlas!')}>
              Submit
            </Button>
          </Card>
        </main>
      </AnnouncementProvider>
    </ThemeProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
```

---

## Package Subpaths

- `@atlas/ds` - All public components, hooks, and providers.
- `@atlas/ds/tokens` - Design token definitions, semantic scales, and token metadata.
- `@atlas/ds/foundations` - Accessibility, interaction, and styling foundation contracts.
- `@atlas/ds/contracts` - Component capability contracts and type definitions.
- `@atlas/ds/components` - Individual component primitives.
- `@atlas/ds/themes` - Theme schemas and theme switching utilities.
- `@atlas/ds/styles.css` - Complete stylesheet bundle.

---

## Documentation

For full framework recipes (Vite, Next.js App Router, Tailwind coexistence) and API guides, see [Consumer Integration Guide](../../docs/engineering/CONSUMER_INTEGRATION.md).
